/*jslint devel: true, node: true */

var firstName, lastName;

firstName = prompt('What is your first name');
lastName = prompt('last name ?');
alert('His first name is ' + firstName);
alert('full name is ' + firstName + ' ' + lastName);